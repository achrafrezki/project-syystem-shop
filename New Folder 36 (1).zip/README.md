# Studio-1MILLION-BroadCast
discord bot
menu +help

![image](https://github.com/user-attachments/assets/63609653-2e6d-4929-8c18-0af6b8db5911)

+ping

![image](https://github.com/user-attachments/assets/87ad8db4-9903-4c38-97e5-e06cc6d8b466)

+support - https://discord.gg/1million

# BroadCast Cmds
+bc <- ALL

+obc <- Online only

+fbc <- Offline only


By : NL_j - Studio 1MILLION

# need node.js
https://nodejs.org/
